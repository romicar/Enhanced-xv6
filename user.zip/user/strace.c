#include "kernel/types.h"
#include "user/user.h"

int main(int argc, char *argv[])
{
    if (argc >= 3)
    {
        int mask = atoi(argv[1]);
        trace(mask);
        // we need to create an array size of argc-2 (for the arguments) + 1 for storing the last 0 
        int sz = argc-1; 
        
        char *commands[sz];
        for (int i = 0; i < sz-1; i++)
            commands[i] = argv[i+2];

        commands[sz-1] = 0;

        exec(commands[0], commands);
        fprintf(2, "failure in exec %s\n", commands[0]);   
    }

    else 
    {
        fprintf(2, "less number of arguments\n");
    }

    exit(1);
}
